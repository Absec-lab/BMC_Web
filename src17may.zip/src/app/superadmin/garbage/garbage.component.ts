import { Component } from '@angular/core';

@Component({
  selector: 'app-garbage',
  templateUrl: './garbage.component.html',
  styleUrls: ['../../common.css','./garbage.component.css']
})
export class GarbageComponent {

}
