import { Component } from '@angular/core';

@Component({
  selector: 'app-mcc',
  templateUrl: './mcc.component.html',
  styleUrls: ['./mcc.component.css']
})
export class MccComponent {

}
